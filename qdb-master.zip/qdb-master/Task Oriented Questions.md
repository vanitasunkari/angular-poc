# add even numbers from an array without using for OR any array without any array method.

# Get character count from an string

# Unmatched Character count from two string and from third string cut character from the same count and get the last uncut character.

# Merge two binary search tree

# Avl binary search tree

# IF a project given to you, which one you choose among Angular vs React. If you select one why?

# Merge to objects programatically instead of using internal functions

# What is the best sorting algorithm

# Write a navigation bar end to end (HTML, CSS with ajax calls)
