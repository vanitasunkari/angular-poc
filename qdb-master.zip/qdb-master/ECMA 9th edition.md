ECMA SCRIPT 9TH EDITION

# Specifications:
`
Async Functions, 
Shared Memory, and 
Atomics
`


#New static methods:

`
Object.values, 
Object.entries 
Object.getOwnPropertyDescriptors
`
