# List CSS 3 new Features.

# Advantages of CSS 3

# Mobile Table and Desktop resolutions

# Media queries for Mobile Table and Desktop resolutions

# Bootstrap - Make image responsive.

# 
