# Purpose

> Storing the images referenced in the md files.
